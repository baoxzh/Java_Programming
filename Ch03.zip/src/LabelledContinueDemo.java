public class LabelledContinueDemo {
}
