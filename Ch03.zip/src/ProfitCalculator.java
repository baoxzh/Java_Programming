public class ProfitCalculator {
    public static void main(String[] args) {
        double cost = 50.0; // 成本
        double sales = 150.0; // 销售额
        double profit = sales - cost; // 利润表达式
        System.out.println("利润为: " + profit);
    }
}