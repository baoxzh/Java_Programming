public class FullNameCreator {
    public static void main(String[] args) {
        String firstName = "张"; // 名
        String lastName = "三"; // 姓
        String fullName = firstName + lastName; // 字符串拼接
        System.out.println("完整姓名：" + fullName);
    }
}