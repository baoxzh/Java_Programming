public class SimpleCountingLoop {
    public static void main(String[] args) {
        int count = 0;
        while (count < 5) {
            System.out.println("计数：" + count);
            count++;
        }
    }
}